/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  Youtube, 
  Download, 
  Music, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Sparkles, 
  RefreshCw, 
  Info, 
  FileAudio, 
  ShieldCheck, 
  ChevronRight, 
  Flame, 
  HelpCircle,
  TrendingUp,
  Volume2,
  HardDrive,
  Cookie,
  Key
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Job } from './types';

export default function App() {
  const [url, setUrl] = useState('');
  const [validationError, setValidationError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [currentJob, setCurrentJob] = useState<Job | null>(null);
  const [hasFfmpeg, setHasFfmpeg] = useState(true);
  const [activeTab, setActiveTab] = useState<'converter' | 'faq'>('converter');
  const [cookies, setCookies] = useState(() => localStorage.getItem('yt_cookies') || '');
  const [showCookiesConfig, setShowCookiesConfig] = useState(false);
  
  const pollingTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Sync cookies to localStorage
  useEffect(() => {
    localStorage.setItem('yt_cookies', cookies);
  }, [cookies]);

  // Validate YouTube URL on-the-fly
  const validateUrl = (value: string) => {
    if (!value.trim()) {
      return '';
    }
    const ytRegex = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/(watch\?v=|embed\/|shorts\/)?([a-zA-Z0-9_-]{11})/;
    if (!ytRegex.test(value)) {
      return 'Please enter a valid YouTube video URL (e.g., https://www.youtube.com/watch?v=...)';
    }
    return '';
  };

  const handleUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setUrl(val);
    setValidationError(validateUrl(val));
  };

  // Poll for job updates
  const startPolling = (jobId: string) => {
    // Clear any existing polling timer
    if (pollingTimerRef.current) {
      clearInterval(pollingTimerRef.current);
    }

    const poll = async () => {
      try {
        const res = await fetch(`/api/job/${jobId}`);
        if (!res.ok) {
          throw new Error('Failed to retrieve process details.');
        }
        const data = await res.json();
        setCurrentJob(data.job);
        setHasFfmpeg(data.hasFfmpeg);

        if (data.job.status === 'completed' || data.job.status === 'failed') {
          if (pollingTimerRef.current) {
            clearInterval(pollingTimerRef.current);
            pollingTimerRef.current = null;
          }
          setIsSubmitting(false);
        }
      } catch (err: any) {
        console.error('Error polling job:', err);
        setCurrentJob(prev => prev ? {
          ...prev,
          status: 'failed',
          error: 'Disconnected from the conversion stream. Please retry.'
        } : null);
        setIsSubmitting(false);
        if (pollingTimerRef.current) {
          clearInterval(pollingTimerRef.current);
          pollingTimerRef.current = null;
        }
      }
    };

    // Poll immediately, then every 1500ms
    poll();
    pollingTimerRef.current = setInterval(poll, 1500);
  };

  // Cleanup polling timer on unmount
  useEffect(() => {
    return () => {
      if (pollingTimerRef.current) {
        clearInterval(pollingTimerRef.current);
      }
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError('');
    setIsSubmitting(true);
    setCurrentJob(null);

    const err = validateUrl(url);
    if (err) {
      setValidationError(err);
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch('/api/convert', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ url, cookies }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Server rejected the video stream.');
      }

      // Initial job tracking
      setCurrentJob({
        id: data.jobId,
        url,
        title: 'Verifying with YouTube...',
        thumbnail: 'https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?w=128&q=80',
        duration: 0,
        status: 'idle',
        progress: 5,
      });

      // Start fetching job status
      startPolling(data.jobId);

    } catch (err: any) {
      console.error('Submit error:', err);
      setValidationError(err.message || 'Connecting to server failed. Verify network connection and try again.');
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setUrl('');
    setCurrentJob(null);
    setValidationError('');
    setIsSubmitting(false);
    if (pollingTimerRef.current) {
      clearInterval(pollingTimerRef.current);
      pollingTimerRef.current = null;
    }
  };

  // Convert duration helper
  const formatDuration = (seconds: number) => {
    if (!seconds) return '0:00';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Determine stage description text
  const getStageDescription = (job: Job) => {
    switch (job.status) {
      case 'idle':
        return 'Initializing video connection...';
      case 'fetching':
        return 'Analyzing streams and thumbnail metadata...';
      case 'downloading':
        return `Extracting digital audio stream (${job.progress}%)`;
      case 'converting':
        return 'Transcoding audio track to high fidelity 192kbps MP3';
      case 'completed':
        return 'Successfully converted and verified!';
      case 'failed':
        return 'Process terminated unexpected.';
      default:
        return 'Processing audio pipeline...';
    }
  };

  return (
    <div className="min-h-screen mesh-bg flex flex-col justify-between text-[#e2e8f0] font-sans selection:bg-purple-600 selection:text-white pb-6 relative">
      <div className="ambient-spot"></div>

      {/* Header Grid */}
      <header className="border-b border-white/10 bg-white/5 backdrop-blur-md sticky top-0 z-30 px-4 py-3 sm:py-4">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-gradient-to-tr from-purple-500 to-blue-500 rounded-xl shadow-lg shadow-purple-500/20 text-white">
              <Youtube className="w-6 h-6" />
            </div>
            <div>
              <h1 className="font-display font-bold text-lg sm:text-xl tracking-tight text-white flex items-center gap-1.5">
                SEHIL YT <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400">Extractor</span>
              </h1>
              <p className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">HIGH-FIDELITY MP3 CONVERTER</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveTab('converter')}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                activeTab === 'converter' 
                  ? 'bg-white/10 text-white border border-white/15' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Converter
            </button>
            <button
              onClick={() => setActiveTab('faq')}
              className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer ${
                activeTab === 'faq' 
                  ? 'bg-white/10 text-white border border-white/15' 
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Supported Limits
            </button>
          </div>
        </div>
      </header>

      {/* Main Body Grid */}
      <main className="flex-grow max-w-4xl w-full mx-auto px-4 py-8 sm:py-12 flex flex-col justify-center relative z-10">
        <AnimatePresence mode="wait">
          {activeTab === 'converter' ? (
            <motion.div
              key="converter-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="space-y-8"
            >
              {/* Introduction Banner */}
              <div className="text-center space-y-3">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-300 text-xs font-semibold font-mono mb-2">
                  <Sparkles className="w-3.5 h-3.5 animate-pulse text-purple-400" />
                  STUDIO QUALITY AUDIO PIPELINE
                </div>
                <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-none">
                  Paste YouTube Link. <br className="sm:hidden" />
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-500 via-indigo-400 to-blue-400">Download Audio.</span>
                </h2>
                <p className="text-slate-400 text-sm sm:text-base max-w-xl mx-auto">
                  A minimalist high-fidelity converter to extract pristine digital soundscapes directly from YouTube. Pure audio streaming, zero waiting queues, auto-deleted storage.
                </p>
              </div>

              {/* Glassmorphism Conversion Layout */}
              <div className="glass-container rounded-[2.5rem] p-6 sm:p-12 relative overflow-hidden">
                <AnimatePresence mode="wait">
                  {!currentJob ? (
                    // Submission State (Enter URL form)
                    <motion.form
                      key="input-form"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      onSubmit={handleSubmit}
                      className="space-y-6"
                    >
                      <div className="space-y-3">
                        <label className="block text-xs font-bold uppercase tracking-widest text-slate-300 font-mono">
                          Video URL stream link
                        </label>
                        <div className="relative group">
                          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                            <Youtube className="h-5.5 w-5.5 text-slate-500 group-focus-within:text-purple-400 transition-colors" />
                          </div>
                          <input
                            type="text"
                            placeholder="Paste YouTube URL here..."
                            value={url}
                            onChange={handleUrlChange}
                            disabled={isSubmitting}
                            className={`block w-full pl-12 pr-28 py-4.5 bg-black/40 border text-white placeholder:text-slate-600 rounded-2xl focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all font-sans text-sm sm:text-base md:tracking-wide ${
                              validationError 
                                ? 'border-red-500/40 focus:ring-red-500/25' 
                                : 'border-white/10'
                            }`}
                          />
                          <div className="absolute right-4 top-1/2 -translate-y-1/2 hidden sm:block">
                            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 bg-white/5 px-2 py-1 rounded border border-white/5">Auto-detect</span>
                          </div>
                        </div>
                        {validationError && (
                          <motion.div 
                            initial={{ opacity: 0, y: -5 }} 
                            animate={{ opacity: 1, y: 0 }} 
                            className="flex items-center gap-1.5 text-xs text-red-400 mt-1.5 font-mono"
                          >
                            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                            {validationError}
                          </motion.div>
                        )}
                      </div>

                      {/* Session Settings / Bypass Bot Check Toggle */}
                      <div className="space-y-3 pt-1">
                        <div className="flex justify-between items-center text-xs">
                          <button
                            type="button"
                            onClick={() => setShowCookiesConfig(!showCookiesConfig)}
                            className="text-slate-400 hover:text-purple-400 font-mono transition-colors flex items-center gap-1.5 cursor-pointer"
                          >
                            <Cookie className="w-4 h-4 text-purple-400" />
                            {showCookiesConfig ? "Hide Session Settings (Bypass check)" : "Fix 'Sign in to confirm you're not a bot' / Session Settings"}
                          </button>
                        </div>

                        {showCookiesConfig && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            className="bg-black/60 border border-purple-500/15 p-5 rounded-2xl space-y-3"
                          >
                            <p className="text-xs text-slate-400 leading-relaxed">
                              YouTube implements bot detection for public cloud platforms. By pasting your browser's YouTube session cookies, you pass authorized requests directly, providing a <span className="text-purple-400 font-semibold font-mono">100% bypass</span> for this limit.
                            </p>
                            <div className="space-y-2">
                              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono">
                                Parse Cookie String or JSON Array
                              </label>
                              <textarea
                                placeholder='Paste Netscape format cookies text string or full JSON array here...
Example from Chrome "EditThisCookie" (JSON array) or "Get cookies.txt" (.txt format)'
                                value={cookies}
                                onChange={(e) => setCookies(e.target.value)}
                                disabled={isSubmitting}
                                className="w-full h-24 p-3 bg-black/60 border border-white/10 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:ring-1 focus:ring-purple-500 placeholder:text-slate-700"
                              />
                            </div>
                            {cookies ? (
                              <div className="flex items-center gap-1 text-[11px] font-mono text-green-400">
                                <ShieldCheck className="w-4 h-4 text-green-400" /> Custom YouTube cookies active
                              </div>
                            ) : (
                              <div className="flex items-center gap-1 text-[11px] font-mono text-amber-400/80">
                                <Info className="w-4 h-4 text-amber-500" /> No active session cookies. Using shared cloud agent fallback.
                              </div>
                            )}
                          </motion.div>
                        )}
                      </div>

                      <div className="pt-2">
                        <button
                          type="submit"
                          disabled={isSubmitting || !!validationError || !url}
                          className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold py-4.5 rounded-2xl text-base sm:text-lg shadow-xl shadow-purple-900/20 transition-all active:scale-[0.98] flex items-center justify-center gap-2 cursor-pointer disabled:from-white/5 disabled:to-white/5 disabled:text-slate-600 disabled:cursor-not-allowed disabled:border disabled:border-white/5"
                        >
                          {isSubmitting ? (
                            <>
                              <RefreshCw className="w-5 h-5 animate-spin" />
                              Connecting Stream...
                            </>
                          ) : (
                            <>
                              <Music className="w-5 h-5" />
                              Convert to MP3
                            </>
                          )}
                        </button>
                      </div>

                      {/* Quick quality badges */}
                      <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 pt-4 border-t border-white/5 text-[10px] uppercase font-bold tracking-widest text-slate-500">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Ultra fast rip
                        </span>
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Professional 192KBPS Bitrate
                        </span>
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-purple-400" /> Strict secure purge
                        </span>
                      </div>
                    </motion.form>
                  ) : (
                    // Processing / Completed States
                    <motion.div
                      key="status-card"
                      initial={{ opacity: 0, scale: 0.98 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.98 }}
                      className="space-y-6"
                    >
                      {/* Video Header Card */}
                      <div className="flex flex-col sm:flex-row gap-4 bg-black/30 p-4.5 rounded-2xl border border-white/5 items-center sm:items-start text-center sm:text-left">
                        <div className="w-28 h-20 sm:w-32 sm:h-24 rounded-xl bg-black/40 overflow-hidden relative border border-white/10 flex-shrink-0 shadow-md">
                          <img 
                            src={currentJob.thumbnail} 
                            alt={currentJob.title}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          {currentJob.duration > 0 && (
                            <span className="absolute bottom-1 right-1 px-1.5 bg-black/80 text-[9px] font-mono font-medium rounded text-white flex items-center gap-0.5">
                              <Clock className="w-2.5 h-2.5" />
                              {formatDuration(currentJob.duration)}
                            </span>
                          )}
                        </div>
                        <div className="space-y-1.5 flex-grow min-w-0">
                          <div className="inline-flex px-2 py-0.5 rounded bg-purple-500/10 text-purple-300 text-[9px] font-mono font-bold uppercase tracking-widest border border-purple-500/10">
                            YouTube Source Video
                          </div>
                          <h3 className="text-sm sm:text-base font-bold text-white leading-snug tracking-tight line-clamp-2">
                            {currentJob.title}
                          </h3>
                          <p className="text-xs text-slate-400 truncate max-w-md font-mono">
                            {currentJob.url}
                          </p>
                        </div>
                      </div>

                      {/* Progress Metrics & Bar */}
                      {currentJob.status !== 'completed' && currentJob.status !== 'failed' && (
                        <div className="w-full p-6 bg-white/5 border border-white/5 rounded-2xl space-y-4">
                          <div className="flex justify-between items-center">
                            <div className="flex items-center gap-3">
                              <div className="w-2.5 h-2.5 bg-blue-400 rounded-full animate-pulse"></div>
                              <span className="text-sm font-medium text-slate-300 italic">{getStageDescription(currentJob)}</span>
                            </div>
                            <span className="text-sm font-mono text-blue-400 font-bold">{currentJob.progress}%</span>
                          </div>

                          <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                            <motion.div
                              className="bg-gradient-to-r from-purple-500 to-blue-500 h-full"
                              initial={{ width: '0%' }}
                              animate={{ width: `${currentJob.progress}%` }}
                              transition={{ duration: 0.3 }}
                            />
                          </div>

                          <div className="flex justify-between text-[10px] uppercase tracking-wider text-slate-500 font-bold">
                            <span>Adaptive stereodec</span>
                            <span>Estimated: {Math.max(2, Math.round((100 - currentJob.progress) * 0.2))} seconds</span>
                          </div>
                        </div>
                      )}

                      {/* Success Controls */}
                      {currentJob.status === 'completed' && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-6 text-center space-y-5"
                        >
                          <div className="flex items-center justify-center gap-2.5 text-emerald-400">
                            <CheckCircle2 className="w-6.5 h-6.5 flex-shrink-0" />
                            <span className="font-display font-semibold text-lg sm:text-xl text-white">Audio Stream Extracted!</span>
                          </div>

                          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs font-mono text-slate-300">
                            {currentJob.fileSize && (
                              <span className="flex items-center gap-1.5">
                                <HardDrive className="w-4 h-4 text-emerald-400" /> Size: {currentJob.fileSize}
                              </span>
                            )}
                            <span className="flex items-center gap-1.5">
                              <Volume2 className="w-4 h-4 text-emerald-400" /> Quality: {hasFfmpeg ? 'MP3 (192kbps LAME)' : 'Original Digital Stream'}
                            </span>
                          </div>

                          {!hasFfmpeg && (
                            <div className="text-left bg-black/40 p-4 border border-white/5 rounded-xl text-xs text-slate-300 max-w-xl mx-auto flex gap-2.5">
                              <Info className="w-4.5 h-4.5 text-purple-400 flex-shrink-0 mt-0.5" />
                              <p>
                                <strong>High Quality Fallback:</strong> Native FFmpeg was not detected on this server host. To maximize fidelity, we extracted the video's original digital stream container (.m4a) directly. It plays beautifully on all devices instantly with zero transcode artifacts!
                              </p>
                            </div>
                          )}

                          <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
                            <a
                              href={`/api/download/${currentJob.id}`}
                              className="px-6 py-4 rounded-xl font-bold tracking-tight text-white bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 hover:scale-[1.01] active:scale-[0.98] transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer shadow-lg text-sm sm:text-base"
                            >
                              <Download className="w-5 h-5" />
                              Download Audio Track
                            </a>
                            <button
                              onClick={resetForm}
                              className="px-6 py-4 rounded-xl text-sm font-bold border border-white/10 bg-white/5 hover:bg-white/10 text-white transition-all duration-200 cursor-pointer"
                            >
                              Extract Another Video
                            </button>
                          </div>

                          <p className="text-[11px] font-mono text-slate-500 italic">
                            For security & protection of your cloud drive, files erase immediately upon download completion.
                          </p>
                        </motion.div>
                      )}

                      {/* Fail Controls */}
                      {currentJob.status === 'failed' && (
                        <motion.div 
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          className="bg-red-500/10 border border-red-500/20 rounded-2xl p-6 text-center space-y-4"
                        >
                          <div className="flex items-center justify-center gap-2 text-red-400">
                            <AlertTriangle className="w-6 h-6 flex-shrink-0" />
                            <span className="font-display font-semibold text-lg text-white">Conversion Encountered an Error</span>
                          </div>

                          <div className="bg-black/40 border border-white/5 p-4 rounded-xl font-mono text-xs text-red-350 max-w-xl mx-auto text-left leading-relaxed">
                            <strong>Feedback:</strong> {currentJob.error || 'The YouTube video stream could not be converted or extracted.'}
                            <div className="mt-3 text-slate-500 text-[10px] leading-normal uppercase font-bold tracking-wide">
                              Notice: Verify that the video is public, is not region locked, and is under the 1-hour limitation standard.
                            </div>
                          </div>

                          <div className="pt-2">
                            <button
                              onClick={resetForm}
                              className="px-6 py-3 rounded-xl font-bold tracking-tight text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-all cursor-pointer text-xs uppercase"
                            >
                              Return to form
                            </button>
                          </div>
                        </motion.div>
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {/* Direct Features Bento Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                <div className="glass-item rounded-2xl p-6 flex flex-col items-center text-center gap-2.5 hover:border-white/10 transition-all hover:bg-white/10 md:h-full">
                  <div className="text-purple-400">
                    <Clock className="w-5.5 h-5.5" />
                  </div>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">Fast Extraction</span>
                  <p className="text-slate-400 text-xs leading-relaxed max-w-xs">
                    60-minute cutoff guards the queue, ensuring conversions start instantly for all active connections.
                  </p>
                </div>

                <div className="glass-item rounded-2xl p-6 flex flex-col items-center text-center gap-2.5 hover:border-white/10 transition-all hover:bg-white/10 md:h-full">
                  <div className="text-blue-400">
                    <ShieldCheck className="w-5.5 h-5.5" />
                  </div>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">Secure Transmission</span>
                  <p className="text-slate-400 text-xs leading-relaxed max-w-xs">
                    Private download engine deletes files immediately after transfer, leaving zero static file trace.
                  </p>
                </div>

                <div className="glass-item rounded-2xl p-6 flex flex-col items-center text-center gap-2.5 hover:border-white/10 transition-all hover:bg-white/10 md:h-full">
                  <div className="text-indigo-400">
                    <FileAudio className="w-5.5 h-5.5" />
                  </div>
                  <span className="text-xs font-bold text-white uppercase tracking-wider">High Fidelity</span>
                  <p className="text-slate-400 text-xs leading-relaxed max-w-xs">
                    Extracts high bitrate dynamic channels up to 192kbps for crystal-clear offline sound reproduction.
                  </p>
                </div>
              </div>
            </motion.div>
          ) : (
            // Supported Limits and FAQs tab
            <motion.div
              key="faq-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.25 }}
              className="space-y-6 max-w-2xl mx-auto"
            >
              <div className="space-y-2 text-center">
                <h2 className="font-display text-2xl sm:text-3xl font-extrabold text-white">
                  Technical Guide & Boundaries
                </h2>
                <p className="text-slate-400 text-xs sm:text-sm">
                  Find configurations, bitrates, and requirements detailed below.
                </p>
              </div>

              <div className="space-y-4">
                <div className="glass-container rounded-2xl p-5 sm:p-6 space-y-2 text-left">
                  <h4 className="font-display font-bold text-sm text-purple-400 flex items-center gap-2">
                    <Clock className="w-4.5 h-4.5" /> Why does the app place a 1-hour stream cutoff?
                  </h4>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                    Downloading and conversion takes active storage buffers and central processing power. A standard length ceiling (60 minutes) protects the server memory and speeds up digital rips significantly.
                  </p>
                </div>

                <div className="glass-container rounded-2xl p-5 sm:p-6 space-y-2 text-left">
                  <h4 className="font-display font-bold text-sm text-purple-400 flex items-center gap-2">
                    <Volume2 className="w-4.5 h-4.5" /> What are the digital quality specifications?
                  </h4>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                    SEHIL YT fetches the maximum resolution audio tracks directly from public streaming structures, packing them cleanly as high-fidelity stereos at up to 192kbps LAME.
                  </p>
                </div>

                <div className="glass-container rounded-2xl p-5 sm:p-6 space-y-2 text-left">
                  <h4 className="font-display font-bold text-sm text-purple-400 flex items-center gap-2">
                    <ShieldCheck className="w-4.5 h-4.5" /> Are private/age-restricted links supported?
                  </h4>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                    Private videos, geo-restricted country lockouts, sub-blocked content, or streams requiring credentials (such as YouTube Shorts with age screening blocks) are restricted for public service safety.
                  </p>
                </div>

                <div className="glass-container rounded-2xl p-5 sm:p-6 space-y-2 text-left">
                  <h4 className="font-display font-bold text-sm text-purple-400 flex items-center gap-2">
                    <HardDrive className="w-4.5 h-4.5" /> How does the security cleanup trigger work?
                  </h4>
                  <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                    Immediately following the completed packet transmittal to your system, a clean loop purges the server's download directories. Any remaining files undergo five-minute sweep cycles instantly.
                  </p>
                </div>
              </div>

              <div className="text-center pt-2">
                <button
                  onClick={() => setActiveTab('converter')}
                  className="inline-flex items-center gap-1.5 px-5 py-3 rounded-xl bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-bold text-xs tracking-tight transition-all cursor-pointer uppercase shadow-lg shadow-purple-950/25"
                >
                  Back to Converter <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Footer Links (translucent alignment) */}
      <footer className="border-t border-white/10 bg-black/40 z-10">
        <div className="max-w-6xl mx-auto px-4 py-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs font-mono text-slate-500 font-bold uppercase tracking-wider">
          <div>
            &copy; {new Date().getFullYear()} SEHIL YT Pipeline 
          </div>
          <div className="flex gap-5">
            <span>Powered by @distube/ytdl-core</span>
            <span>&bull;</span>
            <span>Studio Quality Delivery</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
