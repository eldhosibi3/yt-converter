export interface Job {
  id: string;
  url: string;
  title: string;
  thumbnail: string;
  duration: number; // Duration in seconds
  status: 'idle' | 'fetching' | 'downloading' | 'converting' | 'completed' | 'failed';
  progress: number; // 0 to 100
  error?: string;
  fileName?: string;
  filePath?: string;
  fileSize?: string;
}

export interface ConvertRequest {
  url: string;
}

export interface ConvertResponse {
  jobId: string;
}

export interface JobStatusResponse {
  job: Job;
  hasFfmpeg: boolean;
}
